# Changelog

## 2.3.2 — 2026-10-19

- Keep the extracted body visible while editing or switching submessage patterns.
- Extract main tokens independently of invalid or unfinished submessage drafts; saving still validates all patterns.
- Add body and message-ID token dropdowns from declared main tokens, with automatic input refresh.
- Explain unavailable body values and cover initial loading, invalid patterns, and dropdown changes with regression tests.

## 2.3.1 — 2026-10-19

- Display the extracted submessage.token value as the submessage workbench input, with token-relative capture and partial-debug highlights.
- Keep the editable full event in an Original log tab and extract the configured token when the window opens or F5 is pressed.
- Clear missing/stale body previews and distinguish an empty captured value from failed extraction.
- Verify token selection against the local and official FlexConnector Developer's Guide and add regressions for body changes and failed main matching.

## 2.3.0 — 2026-10-19

- Preview matching regex prefixes when the complete regex fails, in both the main window and submessages.
- Highlight partial text in orange and navigate individual regex elements while preserving original-log offsets.
- Keep actual parser matching and routing separate from the explicitly labeled partial hypothesis.
- Bound prefix probes and cover nested groups, alternatives, quantifiers, anchors, trimming and cancellation with regressions.

## 2.2.1 — 2026-10-19

- Insert new properties beside their category and indexed siblings instead of at the end of the parser.
- Preserve existing submessage and extra processor positions during editor updates.
- Preserve unchanged raw lines and newline style, and avoid repeated processor-comment duplication.
- Cover tokens, nested submessages, event mapping, severity, processors and repeated saves with regression tests.

## 2.2.0 — 2026-10-19

- Redesigned the shared cross-platform submessage editor with persistent message/regex editors,
  separate capture, element, field, advanced-mapping and diagnostics tabs, and clear routing status.
- Added regex-element stepping, clickable capture previews, F5 and optional automatic preview.
- Added independent selected-pattern debugging without changing actual message-ID or pattern routing.
- Preserved full-log highlight offsets through trimming and long body captures; added regression coverage.

## 2.1.0 — 2026-10-19

- Added offline parser proposals from sample logs, with tokens, inferred event fields,
  ordered submessage alternatives, conventional textual severity mappings and sample coverage.
- Added raw token snippets and string-constant previews to event mapping.
- Added source-order regex element navigation with message highlights and explicit unsupported-syntax diagnostics.
- Added regression tests and a guide describing inference assumptions and debugging limits.

## 2.0.1 — 2026-10-14

- Added visible borders and inner padding to message, regex and configuration editors.
- Aligned text inputs, type selectors and buttons across native platforms.
- Kept token format builders on the same row and allocated more width to formats.
- Removed unnecessary input minimum widths that could overflow narrow grid columns.
- Widened the regex timeout input to prevent clipped values on Linux.
- Added native regression checks for wrapped regexes, compact viewports and token alignment.
- Validated the UI on Windows and Ubuntu 26.04 LTS under WSLg.

## 2.0.0 — 2026-10-14

- Added a native Avalonia desktop edition with Windows, Linux and macOS targets.
- Reused ParserCore for properties, regex debugging, token generation, event mapping,
  severity rules, extra processors and ordered submessage routing.
- Added colored message captures, regex group navigation, token snippets, format
  templates, 100-step undo/redo, offline English help and a log-file workbench.
- Added native UI regression tests and self-contained Linux x64 / Windows x64 packaging.
- Verified the native UI on Windows and Ubuntu 26.04 LTS x64 under WSLg.
- Kept the existing Windows WinForms solution available separately. macOS targets
  are available from source but have not been runtime-tested in this release.

## 1.1.0 — 2026-10-14

- Translated all application menus, dialogs, tooltips, accessibility descriptions,
  validation messages and test results into English.
- Translated all eleven searchable offline help topics and the user guide.
- Updated UI regression expectations and screenshots for the English interface.
- Set English framework diagnostic messages without changing the culture used
  for data or regular expressions. Native Windows dialogs follow Windows language settings.
- Prepared C# sources and a matching framework-dependent application package.

Requires Windows and .NET 10 Windows Desktop Runtime. Parser properties, token
names, user log content and ArcSight expressions are preserved as entered.
